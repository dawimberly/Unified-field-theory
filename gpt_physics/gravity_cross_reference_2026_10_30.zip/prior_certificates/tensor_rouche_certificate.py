"""Exact-rational Rouche certificate for one tensor zero in a small disk.
Simpson remainder bounds use analytic fourth-derivative majorants.
All comparisons deciding success are rational; floats are display only.
"""
from fractions import Fraction as F
from math import comb,prod
import json,time
from scalar_rational_certificate import coefficient_bounds

class Q:
    def __init__(self,r=0,i=0):self.r=F(r);self.i=F(i)
    def __add__(self,x):
        if not isinstance(x,Q):x=Q(x)
        return Q(self.r+x.r,self.i+x.i)
    __radd__=__add__
    def __neg__(self):return Q(-self.r,-self.i)
    def __sub__(self,x):return self+-x
    def __mul__(self,x):
        if not isinstance(x,Q):x=Q(x)
        return Q(self.r*x.r-self.i*x.i,self.r*x.i+self.i*x.r)
    __rmul__=__mul__
    def __truediv__(self,x):
        if not isinstance(x,Q):x=Q(x)
        den=x.r*x.r+x.i*x.i
        return self*Q(x.r/den,-x.i/den)
    def upper(self):return abs(self.r)+abs(self.i)
    def lower(self):return max(abs(self.r),abs(self.i))

def simpson(z,n,power):
    total=Q()
    for k in range(n+1):
        t=F(k,n);den=Q(4)+z*(1-t*t)
        reciprocal=Q(1)/den
        if power==2:reciprocal=reciprocal*reciprocal
        total+=reciprocal*(t**6)*(1 if k in (0,n) else (4 if k%2 else 2))
    return total/F(3*n)

def fourth_bound(z_upper,power):
    # d=4+z(1-t^2), |d|>=4, |d'|,|d''|<=2|z|.
    g=[F(1,4)];B=2*z_upper
    for k in range(1,5):
        g.append((k*B*g[k-1]+(comb(k,2)*B*g[k-2] if k>=2 else 0))/4)
    if power==2:g=[sum((F(comb(k,j))*g[j]*g[k-j] for j in range(k+1)),F(0)) for k in range(5)]
    return sum((F(comb(4,j))*prod(range(6-j+1,7))*g[4-j] for j in range(5)),F(0))

def main():
    start=time.monotonic()
    identity=Q(3,4)*(Q(1)/Q(3,4))
    assert identity.r==1 and identity.i==0
    for power in (1,2):
        control=simpson(Q(0),8,power)
        exact=F(1,7*4**power)
        bound=fourth_bound(F(0),power)/F(180*8**4)
        assert control.i==0 and abs(control.r-exact)<=bound
    ab,bb=coefficient_bounds()
    ub=(-ab[1]/3,-ab[0]/3);vb=(bb[0]/15,bb[1]/15)
    u=sum(ub)/2;v=sum(vb)/2;ue=(ub[1]-ub[0])/2;ve=(vb[1]-vb[0])/2
    z=Q(F(223,50),F(718,25));radius=F(1,50) # 4.46+28.72i, radius .02
    assert z.r-radius>0
    n=512
    I=simpson(z,n,1);I2=simpson(z,n,2)
    e1=fourth_bound(z.upper(),1)/F(180*n**4)
    e2=fourth_bound(z.upper(),2)/F(180*n**4)
    inv=Q(1)/z
    value=inv*u+v+z*I/F(120)
    derivative=-(inv*inv)*u+I2/F(30)
    value_upper=value.upper()+ue/z.lower()+ve+z.upper()*e1/120
    derivative_lower=derivative.lower()-ue/z.lower()**2-e2/30
    second_upper=2*ub[1]/(z.lower()-radius)**3+F(1,30240)
    left=derivative_lower*radius
    right=value_upper+second_upper*radius**2/2
    assert left>right>0
    return dict(center=['223/50','718/25'],radius='1/50',Simpson_panels=n,
                linear_term_lower=float(left),nonlinear_and_center_error_upper=float(right),
                strict_Rouche_margin=float(left-right),elapsed_seconds=time.monotonic()-start,
                conclusion='Exactly one zero counted with multiplicity inside |z-(4.46+28.72i)|<.02; all decisive arithmetic is exact rational.',
                proof='On the disk, Re(z)>0 gives |4+z(1-t^2)|>=4. Fourth derivatives bound exact-complex Simpson errors; a uniform second z derivative bounds the Taylor remainder. Rouche compares F to Fprime(center)*(z-center).',
                scope='Fixed L=5 subtractions in the physical-species tensor response. Certifies a response zero, not a physical gravitational mode or quantum equivalence.')
if __name__=='__main__':print(json.dumps(main(),indent=2))
