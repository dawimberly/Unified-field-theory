"""Exact-rational sign certificate; no floating point in certification.
Logarithms bounded by atanh series with an analytic positive tail.
Positive dispersion integral bounded by endpoint denominators on each cell.
The overall positive factor C cancels from the root equation.
"""
from fractions import Fraction as F
import json,time

def log_bounds(x,n=40):
    x=F(x);k=0
    while x>=2:x/=2;k+=1
    assert 1<=x<2
    def series(t):
        total=2*sum((t**(2*j+1)/F(2*j+1) for j in range(n)),F(0))
        tail=2*t**(2*n+1)/(F(2*n+1)*(1-t*t))
        return total,total+tail
    lo,hi=series((x-1)/(x+1));l2,h2=series(F(1,3))
    return lo+k*l2,hi+k*h2

def coefficient_bounds():
    ms=[1,5,10,26];cs=[F(1)]
    for j in range(1,4):
        value=F(-1)
        for k in range(1,4):
            if k!=j:value*=F(1-ms[k],ms[j]-ms[k])
        cs.append(value)
    assert all(sum(c*m**k for c,m in zip(cs,ms))==0 for k in range(3))
    gl=gh=hl=hh=F(0)
    for m,c in zip(ms,cs):
        l,h=log_bounds(m)
        lower,upper=(c*l,c*h) if c>=0 else (c*h,c*l)
        gl+=m*lower;gh+=m*upper;hl+=lower;hh+=upper
    return (-gh/8,-gl/8),(hl/16,hh/16)

def integral_bounds(q,n):
    low=high=F(0)
    primitive=lambda v:3*v**3-F(6,5)*v**5+v**7/7
    previous=F(0)
    for k in range(n):
        left=F(k,n);right=F(k+1,n)
        current=primitive(right);weight=current-previous;previous=current
        assert weight>0
        dl=4+q*(1-left*left);dr=4+q*(1-right*right)
        assert dl>0 and dr>0
        low+=weight/max(dl,dr)
        high+=weight/min(dl,dr)
    return low,high

def main():
    start=time.monotonic();ab,bb=coefficient_bounds();assert ab[1]<0
    endpoints=[F(113,10),F(283,25),F(-261,100),F(-13,5)]
    certificate=[]
    for q in endpoints:
        n=32
        while True:
            il,ih=integral_bounds(q,n)
            aq=sorted([ab[0]/q,ab[1]/q]);ri=sorted([q*il/32,q*ih/32])
            lower=aq[0]+bb[0]+ri[0]
            upper=aq[1]+bb[1]+ri[1]
            if upper<0 or lower>0:break
            n*=2;assert n<=8192
        sign='negative' if upper<0 else 'positive'
        certificate.append(dict(q=str(q),cells=n,certified_sign=sign,
                                display_lower=float(lower),display_upper=float(upper)))
    assert certificate[0]['certified_sign']=='negative'
    assert certificate[1]['certified_sign']=='positive'
    assert certificate[2]['certified_sign']=='negative'
    assert certificate[3]['certified_sign']=='positive'
    return dict(certificate=certificate,
                exact_root_interval=['113/10','283/25'],
                exact_subthreshold_root_interval=['-261/100','-13/5'],
                proof='All sign comparisons use exact Fraction arithmetic, analytic logarithm tail bounds and exact positive cell integrals. Decimal outputs are display only.',
                scope='Unique positive zero of the fixed L=5 subtraction physical-species limit; not a certificate of microscopic validity.',
                elapsed_seconds=time.monotonic()-start)
if __name__=='__main__':print(json.dumps(main(),indent=2))
