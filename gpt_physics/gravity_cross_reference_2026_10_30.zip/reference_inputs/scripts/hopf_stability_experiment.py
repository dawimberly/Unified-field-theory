"""Reproducible exploratory Faddeev-Skyrme experiment; not a gravity model.

Dimensionless unit-radius S3. Piecewise-affine chordal tetrahedral FEM.
E = integral [a/2 |Dn|^2 + b/4 (|Dn|^4-tr((Dn Dn^T)^2))] dV.
Vertex vectors are unit length. No physical units or fitted constants.
"""
import itertools, json, time
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import lsmr
from threadpoolctl import threadpool_limits

# These are many tiny local matrix operations; large BLAS pools slow them down.
threadpool_limits(limits=1)

OUT = Path(__file__).resolve().parents[1] / 'experiments' / 'hopf_first_run'
OUT.mkdir(parents=True, exist_ok=True)

def unit(x):
    return x / np.linalg.norm(x, axis=-1, keepdims=True)

def vertices():
    phi = (1 + np.sqrt(5)) / 2
    points = []
    for i in range(4):
        for s in [-1, 1]:
            p = np.zeros(4); p[i] = s; points.append(p)
    points.extend(itertools.product([-.5, .5], repeat=4))
    for p in itertools.permutations(range(4)):
        inversions = sum(p[i] > p[j] for i in range(4) for j in range(i+1,4))
        if inversions % 2: continue
        for signs in itertools.product([-1,1], repeat=3):
            v = np.array([0, signs[0]/2, signs[1]*phi/2, signs[2]/(2*phi)])
            points.append(v[list(p)])
    return np.unique(np.round(points, 13), axis=0)

def mesh(x):
    t = np.sort(ConvexHull(x).simplices, axis=1)
    orientation = np.linalg.det(np.stack([x[t[:,0]], x[t[:,1]]-x[t[:,0]],
                                         x[t[:,2]]-x[t[:,0]], x[t[:,3]]-x[t[:,0]]], axis=1))
    negative = orientation < 0
    t[negative, :2] = t[negative, 1::-1]
    edges = np.unique(np.sort(t[:, list(itertools.combinations(range(4),2))].reshape(-1,2),axis=1),axis=0)
    B = x[t[:,1:]]-x[t[:,0,None]]
    gram = B @ B.transpose(0,2,1)
    vol = np.sqrt(np.linalg.det(gram))/6
    dual = np.linalg.solve(gram, B)
    basis = np.concatenate([-dual.sum(axis=1,keepdims=True),dual],axis=1)
    return t, edges, vol, basis

def hopf(x, scale=1.):
    # Conformal localization on S3 by stereographic dilation; degree unchanged.
    if scale != 1:
        u = x[:,:3] * 2*scale
        den = (1-x[:,3]) + scale**2*(1+x[:,3])
        y = np.column_stack([u/den[:,None],
            ((scale**2*(1+x[:,3]))-(1-x[:,3]))/den])
    else: y = x
    z = y[:,0]+1j*y[:,1]; w = y[:,2]+1j*y[:,3]
    q = z*np.conj(w)
    return unit(np.column_stack([2*q.real,2*q.imag,abs(z)**2-abs(w)**2]))

def energy(n,t,vol,basis,b=1.):
    G = np.einsum('tiv,tia->tva', n[t],basis)
    C = G @ G.transpose(0,2,1)
    tr = np.trace(C,axis1=1,axis2=2)
    e2 = .5*tr
    e4 = .25*b*(tr**2-(C*C).sum(axis=(1,2)))
    dG = G + b*(tr[:,None,None]*G-C@G)
    local = np.einsum('tva,tia->tiv',dG,basis)*vol[:,None,None]
    grad = np.zeros_like(n)
    np.add.at(grad,t.ravel(),local.reshape(-1,3))
    return float(vol@(e2+e4)),grad,float(vol@e2),float(vol@e4)

def topology(n,t,edges):
    # Geodesic spherical triangle flux. Solve dA=F, then integrate symmetrized
    # cochain cup product. Q is an estimator, not an exact lattice invariant.
    faces = np.unique(np.sort(t[:,list(itertools.combinations(range(4),3))].reshape(-1,3),axis=1),axis=0)
    a,b,c = n[faces[:,0]],n[faces[:,1]],n[faces[:,2]]
    flux = 2*np.arctan2(np.einsum('ij,ij->i',a,np.cross(b,c)),
                        1+(a*b).sum(1)+(b*c).sum(1)+(c*a).sum(1))
    emap = {tuple(e):i for i,e in enumerate(edges)}
    fmap = {tuple(f):i for i,f in enumerate(faces)}
    rows=[]; cols=[]; data=[]
    for i,(a,b,c) in enumerate(faces):
        for e,s in [((b,c),1),((a,c),-1),((a,b),1)]:
            rows.append(i); cols.append(emap[e]); data.append(s)
    D = coo_matrix((data,(rows,cols)),shape=(len(faces),len(edges))).tocsr()
    sol = lsmr(D,flux,atol=1e-10,btol=1e-10,maxiter=2000)
    A = sol[0]
    total=0.; closure=np.zeros(len(t))
    for omitted in range(4):
        ff = np.delete(t,omitted,axis=1)
        sg = np.array([(-1)**sum(row[i]>row[j] for i in range(3) for j in range(i+1,3)) for row in ff])
        ids=np.array([fmap[tuple(sorted(row))] for row in ff])
        closure += (-1)**omitted*sg*flux[ids]
    for p in itertools.permutations(range(4)):
        parity=(-1)**sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))
        q=t[:,p]; e=q[:,:2]; f=q[:,1:]
        es=np.where(e[:,0]<e[:,1],1,-1)
        fs=np.array([(-1)**sum(row[i]>row[j] for i in range(3) for j in range(i+1,3)) for row in f])
        ei=np.array([emap[tuple(sorted(row))] for row in e])
        fi=np.array([fmap[tuple(sorted(row))] for row in f])
        total += parity*np.sum(es*A[ei]*fs*flux[fi])/24
    return dict(hopf_estimate=float(total/(16*np.pi**2)),
                flux_fit_relative=float(np.linalg.norm(D@A-flux)/max(np.linalg.norm(flux),1e-15)),
                max_tetra_flux_closure=float(np.max(abs(closure))),
                min_neighbor_dot=float(np.min(np.sum(n[edges[:,0]]*n[edges[:,1]],axis=1))))

def relax(n,t,vol,basis,b,steps=400):
    records=[]; step=.05
    for k in range(steps+1):
        E,g,e2,e4=energy(n,t,vol,basis,b)
        g-=np.sum(g*n,axis=1,keepdims=True)*n
        rms=float(np.sqrt(np.mean(g*g)))
        if k%10==0: records.append(dict(iteration=k,energy=E,e2=e2,e4=e4,gradient_rms=rms))
        if k==steps or rms<1e-8: break
        norm2=np.sum(g*g)
        for attempt in range(35):
            proposal=unit(n-step*g)
            en=energy(proposal,t,vol,basis,b)[0]
            if en<=E-1e-4*step*norm2: break
            step*=.5
        else: break
        n=proposal; step=min(step*1.2,2.)
    return n,records

def main():
    start=time.time(); x=vertices(); all_results=[]
    rng=np.random.default_rng(20261025)
    for level in [0,1,2]:
        t,edges,vol,basis=mesh(x)
        assert len(x)-len(edges)+len(np.unique(np.sort(t[:,list(itertools.combinations(range(4),3))].reshape(-1,3),axis=1),axis=0))-len(t)==0
        if level==0:
            assert (len(x),len(edges),len(t))==(120,720,600)
        print('mesh',level,len(x),len(t),flush=True)
        seed=hopf(x,2.)
        # Central difference verifies the implemented energy derivative.
        direction=rng.normal(size=seed.shape); direction/=np.linalg.norm(direction)
        E,g,_,_=energy(seed,t,vol,basis)
        eps=1e-6
        fd=(energy(seed+eps*direction,t,vol,basis)[0]-energy(seed-eps*direction,t,vol,basis)[0])/(2*eps)
        grad_error=abs(fd-np.sum(g*direction))/max(1,abs(fd))
        assert grad_error<1e-5,grad_error
        runs=[]
        specs=[('hopf',seed,1.),('perturbed_hopf',unit(seed+.03*rng.normal(size=seed.shape)),1.),
               ('no_quartic_control',seed,0.)] if level<2 else [('hopf',seed,1.)]
        for name,n,b in specs:
            before=topology(n,t,edges)
            final,history=relax(n.copy(),t,vol,basis,b)
            after=topology(final,t,edges)
            uniform=np.tile([0.,0.,1.],(len(x),1))
            assert abs(energy(uniform,t,vol,basis,b)[0])<1e-18
            assert all(history[j+1]['energy']<=history[j]['energy']+1e-9 for j in range(len(history)-1))
            np.savez_compressed(OUT/f'level{level}_{name}.npz',vertices=x,tetrahedra=t,initial=n,final=final)
            r=dict(name=name,quartic_coefficient=b,initial=before,final=after,history=history,
                   final_energy=energy(final,t,vol,basis,b)[0],initial_energy=energy(n,t,vol,basis,b)[0])
            runs.append(r)
            print(name,'E',round(r['initial_energy'],4),'->',round(r['final_energy'],4),
                  'Q',round(before['hopf_estimate'],4),'->',round(after['hopf_estimate'],4),flush=True)
        all_results.append(dict(level=level,vertices=len(x),edges=len(edges),tetrahedra=len(t),
                                chordal_volume=float(sum(vol)),gradient_error=grad_error,runs=runs))
        (OUT/'results.json').write_text(json.dumps(dict(elapsed_seconds=time.time()-start,meshes=all_results),indent=2))
        if level<2:
            x=unit(np.vstack([x,unit(x[edges[:,0]]+x[edges[:,1]])]))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(9,5))
    for m in all_results:
        for r in m['runs']:
            if r['name']=='hopf':
                ax.plot([h['iteration'] for h in r['history']], [h['energy'] for h in r['history']],label=f"{m['vertices']} vertices")
    ax.set(xlabel='Relaxation iteration (not physical time)',ylabel='Dimensionless discrete energy',title='Hopf-seeded Faddeev-Skyrme relaxation on refined S3 meshes')
    ax.legend(); fig.tight_layout(); fig.savefig(OUT/'energy.png',dpi=160)
    print('done',round(time.time()-start,1),flush=True)

if __name__=='__main__': main()
